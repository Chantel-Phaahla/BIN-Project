# =============================================================================
# train_model.R  -  heavy computations for SDHSA_Final_Analysis.Rmd
# Usage (project root):   Rscript train_model.R            (about 15-25 minutes)
#
# Re-creates, from data/train_data.csv, the modelling evidence used in the report:
#   1. 5-fold stratified CV tuning grid for the random forest
#   2. CV comparison: logistic regression vs random forest
#   3. Class-imbalance sensitivity (baseline vs class weights vs down-sampling)
#   4. Refit of the final random forest -> outputs/final_rf_refit.rds
#   5. Permutation variable importance
# Results are written to outputs/*.csv so the Rmd knits in seconds. The deployed
# model data/final_rf.rds is NEVER overwritten by this script.
# =============================================================================
suppressPackageStartupMessages({library(tidyverse); library(tidymodels); library(readr)})
source("modelling.R")
dir.create("outputs", showWarnings = FALSE)
args  <- commandArgs(trailingOnly = TRUE)
FOLDS <- if (length(args) >= 1) as.integer(args[1]) else 5L
tick  <- function(msg) cat(format(Sys.time(), "%H:%M:%S"), msg, "\n")

train <- read_csv("data/train_data.csv", guess_max = Inf, show_col_types = FALSE) %>% clean_data()
rec   <- make_recipe(train)
set.seed(SEED)
folds <- vfold_cv(train, v = FOLDS, strata = FoodInsecure_flag)
ctrl  <- control_resamples(save_pred = TRUE)
mets  <- metric_set(roc_auc, pr_auc, brier_class)

# 1. Tuning grid ---------------------------------------------------------------
tick("1/5 tuning grid")
rf_tune <- rand_forest(trees = 500, mtry = tune(), min_n = tune()) %>%
  set_engine("ranger", num.threads = 2, seed = SEED) %>% set_mode("classification")
grid <- expand_grid(mtry = c(5, 8, 11, 15, 20), min_n = c(2, 10, 25))
tuned <- tune_grid(workflow(rec, rf_tune), resamples = folds, grid = grid, metrics = mets)
tune_res <- collect_metrics(tuned) %>%
  select(mtry, min_n, .metric, mean, std_err) %>%
  pivot_wider(names_from = .metric, values_from = c(mean, std_err)) %>%
  arrange(desc(mean_roc_auc))
write_csv(tune_res, "outputs/tuning_results.csv")
print(tune_res, n = 20)

# helper: out-of-fold metrics per fold -> mean and sd -----------------------------
cv_eval <- function(wf, label) {
  fit <- fit_resamples(wf, folds, metrics = mets, control = ctrl)
  per_fold <- collect_predictions(fit, summarize = FALSE) %>%
    group_by(id) %>%
    group_modify(~ overall_metrics(.x$FoodInsecure_flag, .x$.pred_Insecure)) %>%
    ungroup()
  per_fold %>% summarise(across(-id, list(mean = mean, sd = sd))) %>% mutate(model = label, .before = 1)
}

# 2 + 3. Models and imbalance variants ----------------------------------------------
tick("2/5 logistic regression CV")
res_lr <- cv_eval(workflow(rec, make_lr_spec()), "Logistic regression")

tick("3/5 imbalance variants (RF)")
res_rf <- cv_eval(workflow(rec, make_rf_spec()), "Random forest (final spec)")
w <- c(Insecure = unname(round((1 - mean(train$FoodInsecure_flag == "Insecure")) /
                               mean(train$FoodInsecure_flag == "Insecure"), 2)), Secure = 1)
res_cw <- cv_eval(workflow(rec, make_rf_spec(class_weights = w)), "RF + class weights")
if (requireNamespace("themis", quietly = TRUE)) {
  rec_ds <- make_recipe(train) %>% themis::step_downsample(FoodInsecure_flag, under_ratio = 1)
  res_ds <- cv_eval(workflow(rec_ds, make_rf_spec()), "RF + down-sampling")
} else res_ds <- NULL
write_csv(bind_rows(res_lr, res_rf, res_cw, res_ds), "outputs/cv_model_comparison.csv")
saveRDS(w, "outputs/class_weights_used.rds")

# 4. Final refit -------------------------------------------------------------------
tick("4/5 final refit")
set.seed(SEED)
final_refit <- workflow(rec, make_rf_spec()) %>% fit(train)
saveRDS(final_refit, "outputs/final_rf_refit.rds")

# 5. Permutation importance ---------------------------------------------------------
tick("5/5 permutation importance")
prepped <- prep(rec, training = train)
baked   <- bake(prepped, new_data = NULL)
pimp <- ranger::ranger(FoodInsecure_flag ~ ., data = baked, probability = TRUE, num.trees = 300,
                       mtry = 11, min.node.size = 2, importance = "permutation",
                       num.threads = 2, seed = SEED)
imp <- tibble(feature = names(pimp$variable.importance), permutation = unname(pimp$variable.importance)) %>%
  arrange(desc(permutation))
write_csv(imp, "outputs/permutation_importance.csv")
tick("done")
