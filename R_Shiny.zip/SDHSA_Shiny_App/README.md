# SDHSA Food-Insecurity Risk Screener (BIN381 Milestone 3 - Deployment)

R/Shiny decision-support tool built on the tuned Random Forest from Task 1.
It validates an uploaded household CSV, scores each household, flags those at or above
a chosen probability threshold (default 0.30), and checks the batch for drift and quality.

## Quick start
```r
source("install_packages.R")   # once
shiny::runApp()                # from this folder
```
The app opens with the bundled Milestone 2 test set scored, so every tab has content.
Untick "Use the bundled demo data" and upload a CSV to score your own households.

## Repository layout
| Path | Purpose |
|---|---|
| `app.R` | Shiny interface (score, what-if, monitoring, model card) |
| `preprocess.R` | Fixed cleaning rules, `validate_new_data()`, `score_households()` (shared with the modelling notebook) |
| `monitoring.R` | PSI drift, data-quality, performance and fairness checks; retrain rule |
| `run_monitoring.R` | Same checks for a batch from the command line; appends to `monitoring_logs/log.csv` |
| `data/final_rf.rds` | Fitted tidymodels workflow (recipe + ranger). Learned preprocessing lives inside it |
| `data/train_data.csv` | Reference for drift checks (Milestone 2 training split) |
| `data/test_data.csv`, `data/test_predictions.csv` | Demo data and baseline score distribution |
| `data/threshold_table.csv` | Test-set recall/precision per threshold (from `test_predictions.csv`) |
| `SDHSA_Final_Analysis.Rmd` | Final R Markdown analysis: preprocessing, imbalance, validation, tuning, test evaluation, drivers, limitations (knit to HTML) |
| `modelling.R`, `train_model.R` | Recipe/model/evaluation helpers; slow computations (tuning, CV, refit) writing `outputs/*.csv` |
| `tests/test_deployment.R` | Automated checks of scoring, validation and the app |
| `outputs/` | Cached CV/tuning/importance results and report figures (`outputs/figs/`) |

## Input requirements
One row per household with the same columns as `data/test_data.csv`. Missing essential
columns stop the run with a clear message; extra columns are ignored; text in numeric
columns is converted (with a warning). Codes 9/99 are treated as "unknown".
Include `FoodInsecure_flag` (0/1) only when outcomes are known - it enables performance checks.

## Monitoring from the command line
```
Rscript run_monitoring.R new_batch.csv 0.30
```

## Re-creating the analysis

```
Rscript train_model.R                     # about 10 minutes; writes outputs/*.csv (never overwrites data/final_rf.rds)
Rscript -e 'rmarkdown::render("SDHSA_Final_Analysis.Rmd")'
Rscript tests/test_deployment.R           # must end with 'All deployment checks passed.'
```

Run everything from the project root. `app.R` no longer sets a working directory or installs packages: run `source("install_packages.R")` once, then `shiny::runApp()`.

## Reproducibility notes
- Model files are tied to the package versions used when they were trained; run
  `renv::init()` / `renv::snapshot()` on the machine that trained them and commit `renv.lock`.
- `set.seed(381)` was used for the cross-validation folds in Task 1.
- Data contain household-level survey records: do not publish them in a public repository.
