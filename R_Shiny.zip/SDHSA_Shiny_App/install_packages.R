# One-off setup. For a locked, reproducible environment use renv:
#   install.packages("renv"); renv::init()   (then renv::snapshot() and commit renv.lock)
pkgs <- c("shiny", "bslib", "DT", "ggplot2", "dplyr", "tidyr", "readr", "scales",
          "tidyverse", "tidymodels", "ranger",
          "rmarkdown", "knitr", "patchwork", "themis")
install.packages(setdiff(pkgs, rownames(installed.packages())))
