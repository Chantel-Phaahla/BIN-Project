# =============================================================================
# monitoring.R
# Drift, data-quality and performance checks for the SDHSA food-insecurity
# model (Milestone 3, Task 4). Used by app.R (Monitoring tab) and can be run
# stand-alone on each new data batch (see docs/MONITORING.md).
#
# Baselines come from the held-out test set (4,136 households, Random forest).
# Cut-offs are TEAM-SET operating rules (documented in the report), not
# statistical constants - revisit them when the model is retrained.
# =============================================================================

library(dplyr)

PROVINCES <- c(`1` = "Western Cape", `2` = "Eastern Cape", `3` = "Northern Cape",
               `4` = "Free State", `5` = "KwaZulu-Natal", `6` = "North West",
               `7` = "Gauteng", `8` = "Mpumalanga", `9` = "Limpopo")

DEPLOY_THRESHOLD <- 0.30          # chosen operating point (see Task 3 / Task 4)

# Main drivers shared by both models (RF importance + logistic regression)
DRIFT_VARS <- c("Income_per_capita", "Income_clean_D07", "Age_mean", "HeadAge",
                "ComparativeIncomeCode", "SalaryEarnersInHousehold",
                "ExpenditureBandCode", "TotalGrantRecipients",
                "TotalRooms_clean", "RoofConditionCode", "ProvinceCode")

BASELINE <- list(auc = 0.840, recall = 0.633, precision = 0.488,
                 flag_rate = 0.239)   # RF on test set at threshold 0.30

# status helpers --------------------------------------------------------------
status_low_bad <- function(x, ok, watch) {          # higher is better
  if (is.na(x)) return("n/a")
  if (x >= ok) "OK" else if (x >= watch) "WATCH" else "ALERT"
}
status_band <- function(x, ok_lo, ok_hi, watch_lo, watch_hi) {
  if (is.na(x)) return("n/a")
  if (x >= ok_lo && x <= ok_hi) "OK"
  else if (x >= watch_lo && x <= watch_hi) "WATCH" else "ALERT"
}
psi_status <- function(x) {
  ifelse(is.na(x), "n/a", ifelse(x < 0.10, "OK", ifelse(x < 0.25, "WATCH", "ALERT")))
}

# Population Stability Index ---------------------------------------------------
# PSI = sum((actual% - expected%) * ln(actual% / expected%)); < 0.10 stable,
# 0.10-0.25 moderate shift, >= 0.25 major shift (common industry rule of thumb).
psi_numeric <- function(expected, actual, bins = 10) {
  expected <- suppressWarnings(as.numeric(expected)); actual <- suppressWarnings(as.numeric(actual))
  expected <- expected[!is.na(expected)]; actual <- actual[!is.na(actual)]
  if (length(expected) < 30 || length(actual) < 30) return(NA_real_)
  br <- unique(quantile(expected, probs = seq(0, 1, length.out = bins + 1)))
  if (length(br) < 3) return(psi_categorical(expected, actual))   # near-constant
  br[1] <- -Inf; br[length(br)] <- Inf
  e <- as.numeric(table(cut(expected, br))) / length(expected)
  a <- as.numeric(table(cut(actual,   br))) / length(actual)
  e <- pmax(e, 1e-4); a <- pmax(a, 1e-4)
  sum((a - e) * log(a / e))
}

psi_categorical <- function(expected, actual) {
  expected <- as.character(expected[!is.na(expected)]); actual <- as.character(actual[!is.na(actual)])
  if (length(expected) < 30 || length(actual) < 30) return(NA_real_)
  lv <- union(unique(expected), unique(actual))
  e <- as.numeric(table(factor(expected, lv))) / length(expected)
  a <- as.numeric(table(factor(actual,   lv))) / length(actual)
  e <- pmax(e, 1e-4); a <- pmax(a, 1e-4)
  sum((a - e) * log(a / e))
}

#' Feature drift table: new batch vs the training reference.
drift_table <- function(ref, new, vars = DRIFT_VARS) {
  vars <- intersect(vars, intersect(names(ref), names(new)))
  out <- lapply(vars, function(v) {
    # integer-coded categories (few distinct values) are treated as categorical
    cat_like <- length(unique(ref[[v]])) <= 15
    p <- if (cat_like) psi_categorical(ref[[v]], new[[v]]) else psi_numeric(ref[[v]], new[[v]])
    tibble(variable = v, psi = round(p, 3), status = psi_status(p))
  })
  bind_rows(out)
}

# Rank-based AUC (Mann-Whitney) - no extra packages needed
auc_rank <- function(truth01, prob) {
  ok <- !is.na(truth01) & !is.na(prob); y <- truth01[ok]; p <- prob[ok]
  n1 <- sum(y == 1); n0 <- sum(y == 0)
  if (n1 == 0 || n0 == 0) return(NA_real_)
  (sum(rank(p)[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}

#' Convert a label column (0/1 or "Insecure"/"Secure") to 0/1.
label01 <- function(x) {
  if (is.numeric(x)) return(as.integer(x == 1))
  as.integer(as.character(x) %in% c("Insecure", "1", "TRUE"))
}

#' Performance on a labelled batch (needs a label column + prob_insecure).
performance_check <- function(scores, label_col = "FoodInsecure_flag",
                              threshold = DEPLOY_THRESHOLD, min_pos = 30) {
  stopifnot(label_col %in% names(scores), "prob_insecure" %in% names(scores))
  y <- label01(scores[[label_col]]); p <- scores$prob_insecure
  pred <- as.integer(p >= threshold)
  tp <- sum(pred == 1 & y == 1); fp <- sum(pred == 1 & y == 0)
  fn <- sum(pred == 0 & y == 1); tn <- sum(pred == 0 & y == 0)
  rec <- tp / max(tp + fn, 1); prec <- tp / max(tp + fp, 1)
  overall <- tibble(
    metric   = c("ROC AUC", "Recall", "Precision", "Specificity", "Share flagged"),
    value    = round(c(auc_rank(y, p), rec, prec, tn / max(tn + fp, 1), mean(pred)), 3),
    baseline = c(BASELINE$auc, BASELINE$recall, BASELINE$precision, NA, BASELINE$flag_rate),
    status   = c(status_low_bad(auc_rank(y, p), 0.80, 0.75),
                 status_low_bad(rec, 0.55, 0.50),
                 status_low_bad(prec, 0.40, 0.35),
                 "n/a",
                 status_band(mean(pred), 0.19, 0.29, 0.15, 0.33)))
  prov <- NULL
  if ("ProvinceCode" %in% names(scores)) {
    prov <- scores %>%
      mutate(y = y, pred = pred) %>%
      group_by(ProvinceCode) %>%
      summarise(households = n(), insecure = sum(y), recall = round(sum(pred == 1 & y == 1) / max(sum(y), 1), 3),
                .groups = "drop") %>%
      mutate(province = unname(PROVINCES[as.character(ProvinceCode)]),
             status = ifelse(insecure < min_pos, "too few cases",
                             ifelse(recall < 0.40, "ALERT", ifelse(recall < 0.50, "WATCH", "OK")))) %>%
      select(province, households, insecure, recall, status)
  }
  list(overall = overall, by_province = prov)
}

#' Data-quality checks on an incoming batch.
quality_check <- function(new, ref, cat_vars = c("ProvinceCode", "HeadPopulationGroupCode",
                                                 "HeadSexCode", "GeoTypeCode")) {
  cat_vars <- intersect(cat_vars, intersect(names(ref), names(new)))
  unseen <- vapply(cat_vars, function(v) mean(!(as.character(new[[v]]) %in% as.character(unique(ref[[v]])))), numeric(1))
  vars <- intersect(DRIFT_VARS, names(new))
  miss <- vapply(vars, function(v) mean(is.na(new[[v]])), numeric(1))
  tibble(check = c(paste0("Unseen level share: ", cat_vars), paste0("Missing share: ", vars)),
         value = round(c(unseen, miss), 3)) %>%
    mutate(status = ifelse(grepl("^Unseen", check),
                           ifelse(value > 0.02, "ALERT", ifelse(value > 0, "WATCH", "OK")),
                           ifelse(value > 0.20, "ALERT", ifelse(value > 0.10, "WATCH", "OK"))))
}

#' One-line decision rule used in the report: when to retrain / retire.
retrain_decision <- function(perf = NULL, drift = NULL) {
  reasons <- character()
  if (!is.null(perf)) {
    auc <- perf$overall$value[perf$overall$metric == "ROC AUC"]
    rec <- perf$overall$value[perf$overall$metric == "Recall"]
    if (!is.na(auc) && auc < 0.75) reasons <- c(reasons, "AUC below the 0.75 Milestone 1 success criterion")
    if (!is.na(rec) && rec < 0.50) reasons <- c(reasons, "Recall at the deployed threshold below 0.50")
  }
  if (!is.null(drift)) {
    if (sum(drift$status == "ALERT") >= 3) reasons <- c(reasons, "3 or more key drivers show major drift (PSI >= 0.25)")
  }
  if (length(reasons)) paste("RETRAIN REVIEW:", paste(reasons, collapse = "; ")) else "No retraining trigger met."
}
