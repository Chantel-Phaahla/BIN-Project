# =============================================================================
# SDHSA Food-Insecurity Risk Screener  (Milestone 3 - Task 4, Deployment)
# R/Shiny decision-support tool built on the tuned Random Forest (final_rf.rds)
#
# Run:  shiny::runApp()        (from the project root)
# Needs: data/final_rf.rds, data/train_data.csv, data/test_data.csv,
#        data/test_predictions.csv, data/threshold_table.csv,
#        preprocess.R, monitoring.R   (see README.md)
# =============================================================================

library(shiny)
library(bslib)
library(DT)
library(ggplot2)
library(dplyr)
library(readr)

source("preprocess.R")    # clean_data(), validate_new_data(), score_households()
source("monitoring.R")    # PSI drift, data-quality and performance checks

# ---- Load model and reference data once at start-up ---------------------------
rf_model  <- readRDS("data/final_rf.rds")
ref_train <- read_csv("data/train_data.csv", guess_max = Inf, show_col_types = FALSE)
demo_data <- read_csv("data/test_data.csv",  guess_max = Inf, show_col_types = FALSE)
thr_tbl   <- read_csv("data/threshold_table.csv", show_col_types = FALSE)
ref_score <- read_csv("data/test_predictions.csv", guess_max = Inf, show_col_types = FALSE) %>%
  filter(model == "Random forest") %>% pull(.pred_Insecure)

# "Typical" household used as the starting point of the what-if tab:
# median for continuous columns, most common value for coded columns.
mode_val <- function(x) { x <- x[!is.na(x)]; u <- unique(x); u[which.max(tabulate(match(x, u)))] }
baseline_hh <- demo_data %>%
  select(-any_of(TARGET)) %>%
  summarise(across(everything(),
                   ~ if (is.numeric(.x) && n_distinct(.x) > 15) median(.x, na.rm = TRUE) else mode_val(.x)))
code_choices <- function(v, drop = c(9, 99)) sort(setdiff(unique(na.omit(demo_data[[v]])), drop))

band_cols <- c(Lower = "#2e7d32", Elevated = "#f9a825", High = "#c62828")
status_style <- function(tbl_widget) {
  formatStyle(tbl_widget, "status",
              backgroundColor = styleEqual(c("OK", "WATCH", "ALERT", "n/a", "too few cases"),
                                           c("#d4edda", "#fff3cd", "#f8d7da", "#eeeeee", "#eeeeee")))
}

# ---- UI -------------------------------------------------------------------------
ui <- page_navbar(
  title = "SDHSA Food-Insecurity Risk Screener",
  theme = bs_theme(version = 5, bootswatch = "flatly"),
  fillable = FALSE,

  # ---- 1. Batch scoring ----
  nav_panel("1. Score households",
    layout_sidebar(
      sidebar = sidebar(width = 320,
        h5("Input data"),
        fileInput("file", "Upload household CSV", accept = ".csv"),
        checkboxInput("use_demo", "Use the bundled demo data (Milestone 2 test set)", value = TRUE),
        sliderInput("thr", "Flagging threshold (probability)", min = 0.10, max = 0.60,
                    value = DEPLOY_THRESHOLD, step = 0.05),
        uiOutput("thr_tradeoff"),
        actionButton("run", "Validate & score", class = "btn-primary w-100"),
        hr(),
        downloadButton("dl", "Download scored CSV", class = "w-100"),
        helpText("The download contains household-level data: store and share it according to your POPIA obligations.")
      ),
      div(class = "alert alert-warning",
          strong("Decision support only. "),
          "Scores describe statistical association in survey data, not causes, and are not a basis for ",
          "automatically granting or refusing assistance to an individual household. Results for Gauteng and ",
          "Limpopo are less reliable (see the Model card tab)."),
      uiOutput("val_msgs"),
      layout_columns(col_widths = c(3, 3, 3, 3),
                     value_box("Households scored", textOutput("n_hh")),
                     value_box("Flagged as food insecure", textOutput("n_flag")),
                     value_box("Share flagged", textOutput("p_flag")),
                     value_box("Mean predicted risk", textOutput("mean_p"))),
      layout_columns(col_widths = c(6, 6),
                     card(card_header("Distribution of predicted risk"), plotOutput("hist", height = 280)),
                     card(card_header("Share flagged by province"), plotOutput("prov", height = 280))),
      card(card_header("Highest-risk households (top 200)"), DTOutput("tbl"))
    )
  ),

  # ---- 2. What-if ----
  nav_panel("2. What-if household",
    layout_sidebar(
      sidebar = sidebar(width = 320,
        h5("Describe a household"),
        selectInput("wi_prov", "Province", choices = setNames(names(PROVINCES), PROVINCES), selected = "7"),
        numericInput("wi_inc", "Household monthly income (R)", value = round(median(demo_data$Income_clean_D07, na.rm = TRUE)), min = 0, step = 100),
        numericInput("wi_size", "Household size", value = 4, min = 1, max = 25),
        numericInput("wi_age", "Age of household head", value = 45, min = 15, max = 100),
        selectInput("wi_comp", "Comparative income rating (code)", choices = code_choices("ComparativeIncomeCode"), selected = 3),
        selectInput("wi_exp", "Expenditure band (code)", choices = code_choices("ExpenditureBandCode"), selected = 5),
        selectInput("wi_roof", "Roof condition (code)", choices = code_choices("RoofConditionCode"), selected = 2),
        selectInput("wi_tv", "Pay-TV asset (code)", choices = code_choices("PayTVAssetCode"), selected = 2),
        helpText("Codes follow the Stats SA GHS data dictionary. All other fields are held at typical values.")
      ),
      card(card_header("Estimated risk"), uiOutput("wi_out")),
      div(class = "alert alert-info",
          "Illustrative only. Changing an input shows how the model's estimate moves, which reflects associations in the 2024 survey. ",
          "It does not show that changing that circumstance would change a household's food security.")
    )
  ),

  # ---- 3. Monitoring ----
  nav_panel("3. Monitoring",
    div(class = "container-fluid mt-3",
      p("Runs on the data scored in tab 1. Add a labelled batch (a column ", code("FoodInsecure_flag"),
        " coded 0/1) to see performance checks; unlabelled batches get drift and data-quality checks only."),
      uiOutput("retrain_msg"),
      layout_columns(col_widths = c(6, 6), fill = FALSE,
        card(card_header("Performance vs. baseline"), DTOutput("perf_tbl", height = "auto", fill = FALSE), fill = FALSE),
        card(card_header("Recall by province (fairness check)"), DTOutput("perf_prov", height = "auto", fill = FALSE), fill = FALSE)),
      layout_columns(col_widths = c(6, 6), fill = FALSE,
        card(card_header("Feature drift (PSI vs. training data)"), DTOutput("drift_tbl", height = "auto", fill = FALSE),
             uiOutput("score_psi"), fill = FALSE),
        card(card_header("Data-quality checks"), DTOutput("qual_tbl", height = "auto", fill = FALSE), fill = FALSE))
    )
  ),

  # ---- 4. Model card ----
  nav_panel("4. Model card",
    div(class = "container mt-3",
      h4("What this tool is"),
      p("A tuned Random Forest (ranger; 500 trees, mtry = 11, min_n = 2) trained on 16,548 households from the ",
        "Stats SA General Household Survey (survey year 2024). It estimates the probability that a household is food insecure."),
      h4("Intended use"),
      tags$ul(
        tags$li("Help provincial/municipal planners, NGOs and analysts prioritise areas and programmes for food-security support."),
        tags$li("Batch-score survey microdata that has the same fields as the Milestone 2 analytical dataset."),
        tags$li("Always followed by human review; the score is one input to a decision.")),
      h4("Not intended for"),
      tags$ul(
        tags$li("Automated eligibility decisions about individual households."),
        tags$li("Causal conclusions (e.g. 'raising income by R X removes food insecurity')."),
        tags$li("Data from other surveys, countries or years without re-validation.")),
      h4("Performance on held-out test data (4,136 households)"),
      p("ROC AUC 0.84. At the deployed threshold of 0.30: recall 63%, precision 49%, specificity 85%. ",
        "At the default 0.50: recall 25% - too low to be useful for finding at-risk households."),
      plotOutput("thr_plot", height = 300),
      h4("Known limitations"),
      tags$ul(
        tags$li("Recall differs by province: about 49% in Gauteng and 35% in Limpopo (only 20 food-insecure households in the Limpopo test sample) versus 67-73% in several other provinces."),
        tags$li("Population-group results cannot be assessed: two groups have only 1 and 4 food-insecure households in the test set."),
        tags$li("About half of the households flagged at 0.30 are false alarms."),
        tags$li("Trained on one survey year; income and prices change, so performance should be re-checked every cycle.")))
  )
)

# ---- Server ------------------------------------------------------------------------
server <- function(input, output, session) {

  # Probabilities are computed once per run; the threshold only changes the flag/band.
  raw_scores <- eventReactive(input$run, {
    if (!isTRUE(input$use_demo) && is.null(input$file)) {
      showNotification("Upload a CSV first, or tick 'Use the bundled demo data'.", type = "warning")
      req(FALSE)
    }
    df <- if (!isTRUE(input$use_demo)) {
      read_csv(input$file$datapath, guess_max = Inf, show_col_types = FALSE)
    } else demo_data
    res <- withProgress(message = "Validating and scoring...", value = 0.5,
                        tryCatch(score_households(df, rf_model, threshold = 0.5), error = function(e) e))
    if (inherits(res, "error")) {
      showNotification(conditionMessage(res), type = "error", duration = NULL)
      req(FALSE)
    }
    res
  }, ignoreNULL = FALSE)          # score the demo data on first load

  scored <- reactive({
    thr <- input$thr
    raw_scores()$scores %>%
      mutate(flagged_insecure = prob_insecure >= thr,
             risk_band = cut(prob_insecure, c(-Inf, thr / 2, thr, Inf), labels = c("Lower", "Elevated", "High")),
             province = unname(PROVINCES[as.character(ProvinceCode)]))
  })

  output$thr_tradeoff <- renderUI({
    r <- thr_tbl[which.min(abs(thr_tbl$threshold - input$thr)), ]
    helpText(sprintf("On the Milestone 2 test set this cut-off found %.0f%% of food-insecure households (recall); %.0f%% of flags were correct (precision).",
                     100 * r$recall, 100 * r$precision))
  })

  output$val_msgs <- renderUI({
    m <- raw_scores()$messages
    if (length(m) == 0) return(div(class = "alert alert-success", "Validation passed with no changes."))
    div(class = "alert alert-info", strong("Validation notes"), tags$ul(lapply(m, tags$li)))
  })

  output$n_hh   <- renderText(format(nrow(scored()), big.mark = ","))
  output$n_flag <- renderText(format(sum(scored()$flagged_insecure), big.mark = ","))
  output$p_flag <- renderText(sprintf("%.1f%%", 100 * mean(scored()$flagged_insecure)))
  output$mean_p <- renderText(sprintf("%.1f%%", 100 * mean(scored()$prob_insecure)))

  output$hist <- renderPlot({
    ggplot(scored(), aes(prob_insecure)) +
      geom_histogram(binwidth = 0.025, fill = "#2c7fb8", colour = "white") +
      geom_vline(xintercept = input$thr, linetype = "dashed", colour = "#c62828") +
      labs(x = "Predicted probability of food insecurity", y = "Households") + theme_minimal(base_size = 13)
  })

  output$prov <- renderPlot({
    d <- scored() %>% filter(!is.na(province)) %>% group_by(province) %>%
      summarise(share = mean(flagged_insecure), n = n(), .groups = "drop")
    ggplot(d, aes(share, reorder(province, share))) +
      geom_col(fill = "#2c7fb8") +
      geom_text(aes(label = paste0("n=", n)), hjust = -0.1, size = 3.5) +
      scale_x_continuous(labels = scales::percent, expand = expansion(mult = c(0, 0.2))) +
      labs(x = "Share of households flagged", y = NULL) + theme_minimal(base_size = 13)
  })

  output$tbl <- renderDT({
    scored() %>%
      mutate(row = row_number(), prob_insecure = round(prob_insecure, 3)) %>%
      arrange(desc(prob_insecure)) %>% slice_head(n = 200) %>%
      select(row, province, prob_insecure, risk_band, any_of(c("Income_per_capita", "HeadAge", "HouseholdSize_clean"))) %>%
      datatable(rownames = FALSE, options = list(pageLength = 10, scrollX = TRUE)) %>%
      formatStyle("risk_band", color = styleEqual(names(band_cols), unname(band_cols)), fontWeight = "bold")
  })

  output$dl <- downloadHandler(
    filename = function() paste0("sdhsa_scored_", format(Sys.Date(), "%Y%m%d"), ".csv"),
    content  = function(file) write_csv(scored(), file))

  # ---- what-if ----
  output$wi_out <- renderUI({
    hh <- baseline_hh
    hh$ProvinceCode <- as.integer(input$wi_prov)
    if ("ProvinceClean_D05" %in% names(hh)) hh$ProvinceClean_D05 <- PROVINCES[[input$wi_prov]]
    hh$Income_clean_D07    <- input$wi_inc
    hh$HouseholdSize_clean <- input$wi_size
    hh$Income_per_capita   <- input$wi_inc / max(input$wi_size, 1)
    hh$HeadAge             <- input$wi_age
    hh$ComparativeIncomeCode <- as.numeric(input$wi_comp)
    hh$ExpenditureBandCode   <- as.numeric(input$wi_exp)
    hh$RoofConditionCode     <- as.numeric(input$wi_roof)
    hh$PayTVAssetCode        <- as.numeric(input$wi_tv)
    res <- tryCatch(score_households(hh, rf_model, threshold = input$thr), error = function(e) e)
    if (inherits(res, "error")) return(div(class = "alert alert-danger", conditionMessage(res)))
    s <- res$scores
    band <- as.character(s$risk_band)
    tagList(
      h2(sprintf("%.0f%% estimated probability", 100 * s$prob_insecure),
         style = paste0("color:", band_cols[[band]])),
      p(strong("Risk band: "), band, sprintf(" (flag threshold %.2f from tab 1)", input$thr)),
      p("About 18% of households in the training data were food insecure, so compare the estimate with that base rate."))
  })

  # ---- monitoring ----
  perf <- reactive({
    d <- scored()
    if (!"FoodInsecure_flag" %in% names(d) || all(is.na(d$FoodInsecure_flag))) return(NULL)
    performance_check(d, threshold = input$thr)
  })
  drift   <- reactive(drift_table(ref_train, scored()))
  psi_scr <- reactive(psi_numeric(ref_score, scored()$prob_insecure))

  output$retrain_msg <- renderUI({
    d <- drift()
    if (!is.na(psi_scr()) && psi_scr() >= 0.25) d <- bind_rows(d, tibble(variable = "score", psi = psi_scr(), status = "ALERT"))
    msg <- retrain_decision(perf(), d)
    div(class = paste("alert", if (grepl("^RETRAIN", msg)) "alert-danger" else "alert-success"), strong(msg))
  })

  output$perf_tbl <- renderDT({
    if (is.null(perf())) return(datatable(tibble(note = "No FoodInsecure_flag column in this batch."), rownames = FALSE, options = list(dom = "t")))
    status_style(datatable(perf()$overall, rownames = FALSE, options = list(dom = "t")))
  })
  output$perf_prov <- renderDT({
    if (is.null(perf()) || is.null(perf()$by_province)) return(datatable(tibble(note = "Needs labels and ProvinceCode."), rownames = FALSE, options = list(dom = "t")))
    status_style(datatable(perf()$by_province, rownames = FALSE, options = list(dom = "t", pageLength = 9)))
  })
  output$drift_tbl <- renderDT(status_style(datatable(drift(), rownames = FALSE, options = list(dom = "t", pageLength = 12))))
  output$score_psi <- renderUI(p(class = "mt-2", strong("Score distribution PSI: "),
                                 ifelse(is.na(psi_scr()), "n/a", sprintf("%.3f (%s)", psi_scr(), psi_status(psi_scr())))))
  output$qual_tbl  <- renderDT(status_style(datatable(quality_check(scored(), ref_train), rownames = FALSE, options = list(dom = "t", pageLength = 20))))

  # ---- model card ----
  output$thr_plot <- renderPlot({
    thr_tbl %>% select(threshold, Recall = recall, Precision = precision) %>%
      tidyr::pivot_longer(-threshold) %>%
      ggplot(aes(threshold, value, colour = name)) +
      geom_line(linewidth = 1) + geom_point() +
      geom_vline(xintercept = DEPLOY_THRESHOLD, linetype = "dashed") +
      scale_y_continuous(labels = scales::percent) +
      labs(x = "Flagging threshold", y = NULL, colour = NULL,
           title = "Recall / precision trade-off (test set)") + theme_minimal(base_size = 13)
  })
}

shinyApp(ui, server)
