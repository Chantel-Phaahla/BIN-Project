# =============================================================================
# run_monitoring.R - batch monitoring without the Shiny app
# Usage:  Rscript run_monitoring.R path/to/new_batch.csv [threshold]
# Scores the batch, runs drift / data-quality / (if labelled) performance checks,
# writes CSVs to monitoring_logs/ and appends one line to monitoring_logs/log.csv
# =============================================================================
suppressMessages({library(dplyr); library(readr)})
source("preprocess.R"); source("monitoring.R")

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 1) stop("Usage: Rscript run_monitoring.R new_batch.csv [threshold]")
thr <- if (length(args) >= 2) as.numeric(args[2]) else DEPLOY_THRESHOLD

rf_model  <- readRDS("data/final_rf.rds")
ref_train <- read_csv("data/train_data.csv", guess_max = Inf, show_col_types = FALSE)
ref_score <- read_csv("data/test_predictions.csv", guess_max = Inf, show_col_types = FALSE) %>%
  filter(model == "Random forest") %>% pull(.pred_Insecure)

new    <- read_csv(args[1], guess_max = Inf, show_col_types = FALSE)
res    <- score_households(new, rf_model, threshold = thr)
scores <- res$scores %>% mutate(flagged_insecure = prob_insecure >= thr)

drift  <- drift_table(ref_train, scores)
qual   <- quality_check(scores, ref_train)
psi_s  <- psi_numeric(ref_score, scores$prob_insecure)
perf   <- if ("FoodInsecure_flag" %in% names(scores) && !all(is.na(scores$FoodInsecure_flag)))
            performance_check(scores, threshold = thr) else NULL
if (psi_s >= 0.25 && !is.na(psi_s)) drift <- bind_rows(drift, tibble(variable = "score", psi = psi_s, status = "ALERT"))
decision <- retrain_decision(perf, drift)

dir.create("monitoring_logs", showWarnings = FALSE)
stamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
write_csv(drift, file.path("monitoring_logs", paste0("drift_", stamp, ".csv")))
write_csv(qual,  file.path("monitoring_logs", paste0("quality_", stamp, ".csv")))
if (!is.null(perf)) {
  write_csv(perf$overall, file.path("monitoring_logs", paste0("performance_", stamp, ".csv")))
  write_csv(perf$by_province, file.path("monitoring_logs", paste0("province_recall_", stamp, ".csv")))
}
log_line <- tibble(timestamp = stamp, file = basename(args[1]), n = nrow(scores), threshold = thr,
                   share_flagged = round(mean(scores$flagged_insecure), 3), score_psi = round(psi_s, 3),
                   drift_alerts = sum(drift$status == "ALERT"), decision = decision)
write_csv(log_line, "monitoring_logs/log.csv", append = file.exists("monitoring_logs/log.csv"))
cat(decision, "\n")
