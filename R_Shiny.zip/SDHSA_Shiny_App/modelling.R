# =============================================================================
# modelling.R
# Model-building and evaluation helpers for the SDHSA food-insecurity project
# (Milestone 4 - Person 2, Data Science & R/Shiny).
#
# Sourced by:  SDHSA_Final_Analysis.Rmd   and   train_model.R
#
# Contents
#   1. make_recipe()        - the learned preprocessing recipe (identical to the
#                             recipe stored inside data/final_rf.rds)
#   2. make_rf_spec() / make_lr_spec()
#   3. Evaluation helpers   - confusion metrics, threshold table, calibration,
#                             bootstrap CI, subgroup recall, recall at top-k
#
# Convention used everywhere: `truth` is a factor with levels c("Insecure",
# "Secure") (positive class FIRST, as produced by clean_data() in preprocess.R)
# and `prob` is the predicted probability of "Insecure".
# =============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(tidymodels)
})
source("preprocess.R")   # TARGET, drop_cols, clean_data()
source("monitoring.R")   # auc_rank(), label01() (rank-based AUC without extra packages)

SEED <- 381              # same seed the team used for the CV folds in Milestone 3

# ---- 1. Preprocessing recipe --------------------------------------------------
# Only LEARNED steps are here (fixed rules live in preprocess.R::clean_data()).
# Every step is estimated on the training data only and then re-applied
# unchanged to validation folds, the test set and new data, so nothing leaks.
make_recipe <- function(data) {
  recipe(FoodInsecure_flag ~ ., data = data) %>%
    step_rm(any_of(drop_cols)) %>%                         # IDs, weights, duplicates, raw copies
    step_indicate_na(RentRaw_clean) %>%                    # rent is missing for non-renters: keep that signal
    step_impute_median(all_numeric_predictors()) %>%       # medians learned from training data
    step_impute_mode(all_nominal_predictors()) %>%         # modes learned from training data
    step_novel(all_nominal_predictors(), new_level = "new") %>%   # unseen category at scoring time
    step_other(all_nominal_predictors(), threshold = 0.01) %>%    # pool levels below 1%
    step_dummy(all_nominal_predictors()) %>%
    step_zv(all_predictors()) %>%                          # zero variance
    step_nzv(all_predictors()) %>%                         # near-zero variance
    step_corr(all_numeric_predictors(), threshold = 0.95) %>%     # drop one of each |r| > 0.95 pair
    step_lincomb(all_numeric_predictors()) %>%             # exact linear combinations
    step_normalize(all_numeric_predictors())               # needed by logistic regression
}

# ---- 2. Model specifications --------------------------------------------------
make_rf_spec <- function(mtry = 11, min_n = 2, trees = 500,
                         importance = "impurity", class_weights = NULL,
                         threads = 2, seed = SEED) {
  args <- list(importance = importance, num.threads = threads, seed = seed)
  if (!is.null(class_weights)) args$class.weights <- class_weights
  rand_forest(trees = trees, mtry = mtry, min_n = min_n) %>%
    set_engine("ranger", !!!args) %>%
    set_mode("classification")
}

make_lr_spec <- function() logistic_reg() %>% set_engine("glm")

# ---- 3. Evaluation helpers ----------------------------------------------------

#' Confusion-matrix metrics for one threshold.
cls_metrics <- function(truth, prob, threshold = 0.30) {
  y    <- truth == "Insecure"
  pred <- prob >= threshold
  tp <- sum(pred & y);  fp <- sum(pred & !y)
  fn <- sum(!pred & y); tn <- sum(!pred & !y)
  recall <- tp / (tp + fn); precision <- if (tp + fp) tp / (tp + fp) else NA_real_
  tibble(threshold = threshold, tp = tp, fp = fp, fn = fn, tn = tn,
         recall = recall, precision = precision, specificity = tn / (tn + fp),
         f1 = 2 * precision * recall / (precision + recall),
         flagged_share = mean(pred))
}

#' Metrics over a grid of thresholds (>= rule, as used by the Shiny app).
threshold_table <- function(truth, prob, thresholds = round(seq(0.10, 0.60, by = 0.05), 2)) {
  map_dfr(thresholds, ~ cls_metrics(truth, prob, .x))
}

#' Predicted vs observed risk by probability band (calibration).
calibration_table <- function(truth, prob,
                              breaks = c(0, .1, .2, .3, .4, .5, .6, .7, 1.0001)) {
  tibble(y = as.integer(truth == "Insecure"), p = prob) %>%
    mutate(band = cut(p, breaks, right = FALSE)) %>%
    group_by(band) %>%
    summarise(households = n(), mean_predicted = mean(p), observed_rate = mean(y),
              .groups = "drop")
}

#' Percentile bootstrap CI for ROC AUC and recall at a threshold.
bootstrap_ci <- function(truth, prob, threshold = 0.30, B = 1000, seed = SEED) {
  set.seed(seed)
  y <- as.integer(truth == "Insecure"); n <- length(y)
  res <- map_dfr(seq_len(B), function(b) {
    i <- sample.int(n, n, replace = TRUE)
    tibble(auc    = auc_rank(y[i], prob[i]),
           recall = sum(prob[i] >= threshold & y[i] == 1) / sum(y[i]))
  })
  tibble(metric = c("ROC AUC", paste0("Recall at ", threshold)),
         lower = c(quantile(res$auc, .025), quantile(res$recall, .025)),
         upper = c(quantile(res$auc, .975), quantile(res$recall, .975)))
}

#' Recall within each level of a grouping variable (fairness check).
subgroup_recall <- function(data, truth, prob, group, threshold = 0.30, min_pos = 30) {
  tibble(g = data[[group]], y = truth == "Insecure", flag = prob >= threshold) %>%
    group_by(g) %>%
    summarise(households = n(), insecure = sum(y),
              recall = sum(flag & y) / sum(y),
              flagged_share = mean(flag),
              .groups = "drop") %>%
    mutate(note = ifelse(insecure < min_pos, "too few cases", "")) %>%
    rename(!!group := g)
}

#' Share of truly insecure households found when the top `share` of scores is flagged
#' (threshold-free, so it is comparable between models with differently scaled scores).
recall_at_top <- function(truth, prob, share = 0.24) {
  y <- truth == "Insecure"
  cut <- quantile(prob, 1 - share)
  sum(prob >= cut & y) / sum(y)
}

#' Probability-quality and ranking metrics for one set of predictions.
overall_metrics <- function(truth, prob, share = 0.24) {
  y <- as.integer(truth == "Insecure")
  tibble(roc_auc = auc_rank(y, prob),
         pr_auc  = yardstick::pr_auc_vec(truth, prob, event_level = "first"),
         brier   = mean((prob - y)^2),
         recall_top24 = recall_at_top(truth, prob, share))
}
